package mno;

import LogEngine.ESBLog;
import QUEUES_TOPICS.QueueWriter;
import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.TimerTask;

public class MobileMoneyRequest extends TimerTask {

    DBFunctions dbf = new DBFunctions();
    HashMap<String, String> b2crecord = new HashMap();
    String updatetablequery = "";

    @Override
    public void run() {
        try {
             System.err.println("========-MNOB2C REQUEST-===========");
            ESBLog lg = new ESBLog(Thread.currentThread().getName(), sdf.format(new Date()) + " B2C MOBILE MONEY PROCESSING STARTED...");
            lg.logConsole();
            b2crecord = dbf.getSingleMNOB2C();
            //System.out.println(b2crecord);
            if (!b2crecord.isEmpty()) {
                String corrid = dbf.getCorrelationID();
                if (corrid != null) {
                    String blkcorrid = "EC" + corrid;
                    updatetablequery = "UPDATE TBBULKUPLOADS_MNO set REFNO = '" + blkcorrid + "', PICKED = 1 WHERE ID = '" + b2crecord.get("ID").trim() + "'";
                    if (dbf.query(updatetablequery)) {
                        //we got data so we send one b2c request to esb
                        HashMap<String, String> esbrequest = new HashMap();
                        esbrequest.put("MTI", "0200");
                        esbrequest.put("3", "440000");
                        esbrequest.put("destination", "xml");
                        esbrequest.put("source", "internetbanking");
                        esbrequest.put("direction", "request");
                        esbrequest.put("2", b2crecord.get("MOBILE_NO"));
                        esbrequest.put("4", b2crecord.get("AMOUNT"));
                        esbrequest.put("65", b2crecord.get("MOBILE_NO"));
                        esbrequest.put("38", b2crecord.get("IB_BATCHNO"));
                        esbrequest.put("37", blkcorrid);
                        esbrequest.put("24", "NOUPLOAD");
                        esbrequest.put("25", b2crecord.get("RECORD_ID"));
                        esbrequest.put("26", "BULKUPLOAD");
                        esbrequest.put("100", b2crecord.get("SERVICE_CODE"));
                        esbrequest.put("102", b2crecord.get("DRACCOUNT"));
                        //send to b2c single request to esb
                        QueueWriter qw = new QueueWriter("jms/ESBRequest_queue_DS");
                        if (qw.sendObject(esbrequest, blkcorrid)) {
                            updatetablequery = "UPDATE TBBULKUPLOADS_MNO set  SENT = 1, TIMETOESB = SYSDATE WHERE ID = '" + b2crecord.get("ID").trim() + "'";
                            dbf.query(updatetablequery);
                        }
                        ESBLog strt = new ESBLog(Thread.currentThread().getName(),
                                sdf.format(new Date()) + " "
                                + " B2C FROM BULK " + esbrequest);
                        strt.logConsole();
                    }
                } else {
                    throw new NullPointerException("COULD NOT GET CORRELATION ID FROM DB SEQUENCE AT : " + Thread.currentThread().getName());
                }
            }
             
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }

}
