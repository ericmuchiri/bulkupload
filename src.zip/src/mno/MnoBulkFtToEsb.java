package mno;

import utils.ESBxml;
import LogEngine.ESBLog;
import callBackResponse.SendResponse;
import database.Config;
import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.TimerTask;

/**
 * CLASS TO SEND BULK DISTINCT TO FLEX
 *
 * @author ERIC
 */
public class MnoBulkFtToEsb extends TimerTask {

    DBFunctions dbf = new DBFunctions();
    HashMap<String, String> xmlMapRequest = new HashMap();
    HashMap<String, String> xmlMapResponse = new HashMap();
    String updatetablequery = "";
    String esb_bulk_refno = null;
    String esb_batchnumber = null;
    String network_service_code = null;
    ESBxml exml = new ESBxml();

    //list of networks in batch with sum,draccount,and esbbatchnumber
    ArrayList<HashMap<String, String>> bulkmnos_networks = new ArrayList<>();

    /**
     * Check if exist un-proccessed unique batch number in mno table if exist-
     * sum (amount) per network into an ArrayList then prepare EsbMessage for
     * each network.
     */
    @Override
    public void run() {
        try {
             System.err.println("\n========<MNO_BULK_FT>============");
            ESBLog lg = new ESBLog(Thread.currentThread().getName(), "\n" + sdf.format(new Date()) + " STARTED MNOB2C BULK FT TO ESB TIMER");
            lg.logConsole();
            esb_batchnumber = dbf.getUnProcessdMnoBatchInFlex();
            if (esb_batchnumber != null) {
                bulkmnos_networks = dbf.getBulkMnoFt(esb_batchnumber);
                prepareEsbMessage();
            } else {
                ESBLog noreq = new ESBLog(Thread.currentThread().getName(), sdf.format(new Date()) + " No PENDING MNOB2C BULK batch UNPROCESSED");
                noreq.logConsole();
                //no unpocessed mno bulk
            }
             System.err.println("========</MNO_BULK_FT>============\n");
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el2 = new ESBLog(sw.toString() + "run");
            el2.log();
        }

    }

    /**
     * Update the batch as picked for processing Loop to get unique network for
     * processing get collection account for mno get esb ref and update for that
     * network that batchnumber CALL postToEsb() to post xml
     */
    private void prepareEsbMessage() {
        ESBLog lg = new ESBLog(Thread.currentThread().getName(), sdf.format(new Date()) + " Processing bulk for " + esb_batchnumber);
        lg.logConsole();
        try {
            updatetablequery = "UPDATE TBIBUPLOADS_TOMNO SET  PICKED_TO_FLEX=1 WHERE ESB_BATCHNO='" + esb_batchnumber + "' ";
            if (dbf.query(updatetablequery)) {
                System.out.println("Processing bulk");
                for (int i = 0; i < bulkmnos_networks.size(); i++) {
                    HashMap<String, String> onerecord = (HashMap<String, String>) bulkmnos_networks.get(i);
                    network_service_code = onerecord.get("NETWORK");
                    String MnoCollectionAccount = dbf.getMnoCollectionAccount(network_service_code);

                    if (MnoCollectionAccount != null) {
                        esb_bulk_refno = "EC" + dbf.getCorrelationID();
                        xmlMapRequest.put("0", "0200");
                        xmlMapRequest.put("2", onerecord.get("IB_BATCHNO"));
                        xmlMapRequest.put("3", "400000");
                        xmlMapRequest.put("4", onerecord.get("AMOUNT"));
                        xmlMapRequest.put("24", onerecord.get("ESB_BATCHNO"));
                        xmlMapRequest.put("25", "TZS");
                        xmlMapRequest.put("37", esb_bulk_refno);
                        xmlMapRequest.put("88", network_service_code + " Bulk FT");
                        xmlMapRequest.put("100", "BULKMNOFT");
                        xmlMapRequest.put("102", onerecord.get("DRACCOUNT"));
                        xmlMapRequest.put("103", MnoCollectionAccount);
                        ///generate xml from hashmap
                        String reqxml = exml.generateXMLfromMap(xmlMapRequest, true);
                        updatetablequery = "UPDATE TBIBUPLOADS_TOMNO  SET TIMETOESB=SYSDATE, SENT_TO_FLEX=1, ESB_BULK_REFNO='" + esb_bulk_refno + "' WHERE ESB_BATCHNO='" + esb_batchnumber + "' AND SERVICE_CODE='" + network_service_code + "'";
                        if (dbf.query(updatetablequery)) {
                            System.out.println("Sending FT... " + network_service_code + "@" + esb_batchnumber);
                            postToEsb(reqxml);
                        }
                    } else {
                        System.out.println("Collection account for " + network_service_code + " not found ");
                        updatetablequery = " UPDATE TBIBUPLOADS_TOMNO SET HOST_RESPONSE='Collection account for " + network_service_code + "not found '"
                                + " WHERE ESB_BATCHNO='" + esb_batchnumber + "' AND SERVICE_CODE='" + network_service_code + "'";
                        dbf.query(updatetablequery);
                    }

                }
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el2 = new ESBLog(sw.toString() + "prepareEsbMessage()");
            el2.log();
        }
    }

    /**
     *
     * @param xml_message post message to esb
     */
    private void postToEsb(String xml_message) {
        try {
            ESBLog el2 = new ESBLog("MNOB2C BULK FT TO ESB", xml_message);
            el2.log();
            URL url = new URL(Config.ESBWSConnector);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(600000);
            conn.setReadTimeout(600000);
            OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
            osw.write(xml_message);
            osw.flush();

            ///response
            String inputLine;
            StringBuffer stringBuffer = new StringBuffer();
            BufferedReader bufferedReader = null;
            InputStream resStream = conn.getInputStream();
            InputStreamReader streamReader = new InputStreamReader(resStream);
            bufferedReader = new BufferedReader(streamReader);
            while ((inputLine = bufferedReader.readLine()) != null) {
                stringBuffer.append(inputLine);
            }
            int httpCode = conn.getResponseCode();

            xmlMapResponse = exml.parseESBXML(stringBuffer.toString());
            if (httpCode == 200) {
                ESBLog reshm = new ESBLog("reshm", xmlMapResponse);
                reshm.log();

                if (!xmlMapResponse.isEmpty()) {
                    if (xmlMapResponse.get("39").equals("00")) {
                        ESBLog lg = new ESBLog(Thread.currentThread().getName(), sdf.format(new Date()) + "TXN SUCCESSFUL  FOR " + network_service_code + "@" + esb_batchnumber);
                        lg.logConsole();
                        //update this network as ready for 
                        updatetablequery = "UPDATE TBIBUPLOADS_TOMNO SET  HOST_RESPONSE='" + xmlMapResponse.get("48") + "', ";
                        updatetablequery += " HOST_REF='" + xmlMapResponse.get("121") + "' ,  RESPONSE_CODE='00'";
                        updatetablequery += " WHERE ESB_BULK_REFNO='" + esb_bulk_refno + "' ";
                        dbf.query(updatetablequery);
                        ///generate call back to ib client as per the network
                        /*
                        callBack("1")
                         */

                    } else {
                        ESBLog lg = new ESBLog(Thread.currentThread().getName(), sdf.format(new Date()) + "TXN FAILED  FOR " + network_service_code + "@" + esb_batchnumber);
                        lg.logConsole();
                        updatetablequery = "UPDATE TBIBUPLOADS_TOMNO SET  HOST_RESPONSE='" + xmlMapResponse.get("48") + "', ";
                        updatetablequery += " RESPONSE_CODE='" + xmlMapResponse.get("39") + "'";
                        updatetablequery += " WHERE ESB_BULK_REFNO='" + esb_bulk_refno + "' ";
                        dbf.query(updatetablequery);
//                        callBack("1")
                    }
                }
            } else {
                ////service unavailable
                String errormsg = "http error " + httpCode + ": " + conn.getResponseMessage();
                ESBLog lg = new ESBLog(Thread.currentThread().getName(), sdf.format(new Date()) + "HTTP ERROR  " + network_service_code + "@" + esb_batchnumber);
                lg.logConsole();
                updatetablequery = "UPDATE TBIBUPLOADS_TOMNO SET  HOST_RESPONSE='" + errormsg + "' ";
                updatetablequery += " WHERE ESB_BULK_REFNO='" + esb_bulk_refno + "' ";
                dbf.query(updatetablequery);

            }

        } catch (Exception e) {
            String errormsg = "Error:" + e.getMessage();
            updatetablequery = "UPDATE TBIBUPLOADS_TOMNO SET  HOST_RESPONSE='" + errormsg + "' ";
            updatetablequery += " WHERE ESB_BULK_REFNO='" + esb_bulk_refno + "' ";
            dbf.query(updatetablequery);

            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el2 = new ESBLog(" postToEsb(String xml_message) " + sw.toString());
            el2.log();
        }
    }

    private void callBack(String status) {
        HashMap<String, String> response = new HashMap();
        response.put("RES_TYPE", "MNOB2C");
        response.put("RECORDID", ""); //FOR SINGLE TXN USE RECORD ID
        response.put("TXNREFID", "");
        response.put("DESCRIPTION", "");
        response.put("STATUSCODE", status.equalsIgnoreCase("00") ? "1" : "2");
        SendResponse sr = new SendResponse(response);
        sr.httpsRequest();
    }

}
