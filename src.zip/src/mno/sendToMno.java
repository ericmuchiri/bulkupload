package mno;

import LogEngine.ESBLog;
import QUEUES_TOPICS.TopicWriter;
import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.TimerTask;

/**
 *
 * @author ERIC
 */
public class sendToMno extends TimerTask {

    DBFunctions dbf = new DBFunctions();
    HashMap<String, String> b2crecord = new HashMap();
    String updatetablequery = "";

    @Override
    public void run() {
        try {
            ESBLog lg = new ESBLog(Thread.currentThread().getName(), "\n" + sdf.format(new Date()) + " RUN SINGLE TXN TO Mno");
            lg.logConsole();
            //////ge
            b2crecord = dbf.getSingleMNOB2C();
            System.out.println("records " + b2crecord);
            if (!b2crecord.isEmpty()) {
                String corrid = dbf.getCorrelationID();
                if (corrid != null) {
                    String txn_Refno = "EC" + corrid;
                    updatetablequery = "UPDATE TBIBUPLOADS_TOMNO set TXN_REFNO = '" + txn_Refno + "', PICKED_TOMNO = 1 WHERE ID = '" + b2crecord.get("ID").trim() + "'";
                    if (dbf.query(updatetablequery)) {
                        System.out.println("**** Sending " + b2crecord.get("AMOUNT") + " to " + b2crecord.get("SERVICE_CODE"));
                        HashMap<String, String> esbrequest = new HashMap();
                        esbrequest.put("MTI", "0200");
                        esbrequest.put("3", "440000");
                        esbrequest.put("destination", "xml");
                        esbrequest.put("source", "internetbanking");
                        esbrequest.put("direction", "request");
                        esbrequest.put("CorrelationID", txn_Refno);
                        esbrequest.put("2", b2crecord.get("MOBILE_NO"));
                        esbrequest.put("4", b2crecord.get("AMOUNT"));
                        esbrequest.put("65", b2crecord.get("MOBILE_NO"));
                        esbrequest.put("38", b2crecord.get("ESB_BATCHNO"));
                        esbrequest.put("37", txn_Refno);
                        esbrequest.put("FCCREF", b2crecord.get("ESB_BULK_REFNO"));
                        esbrequest.put("XREF", txn_Refno);
                        esbrequest.put("39", "00"); ///it was successful in flex..
                        esbrequest.put("100", b2crecord.get("SERVICE_CODE"));
                        esbrequest.put("102", b2crecord.get("DRACCOUNT"));

                        ESBLog strt = new ESBLog("topic to mnos", esbrequest);
                        strt.logConsole();
                        //send to b2c single request to esb
                        TopicWriter tw = new TopicWriter("jms/ESBAdaptor_Requests_Topic_DS");
                        if (tw.sendObject(esbrequest, b2crecord.get("SERVICE_CODE"))) {
                            updatetablequery = "UPDATE TBIBUPLOADS_TOMNO set  SENT_TO_MNO = 1, TIME_TOMNO = SYSDATE WHERE ID = '" + b2crecord.get("ID").trim() + "'";
                            dbf.query(updatetablequery);
                        }
                    }
                } else {
                    throw new NullPointerException("COULD NOT GET CORRELATION ID FROM DB SEQUENCE AT : " + Thread.currentThread().getName());
                }
            }

        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el2 = new ESBLog(sw.toString() + "SaveBulkRecords(ArrayList bulkrecords)");
            el2.log();
        }

    }
}
