/*
 * Read TBMESSAGES for MNOB2C Response
 * Update TBIBUPLOADS_TOMNO
 * and open the template in the editor.
 */
package mno;

import LogEngine.ESBLog;
import callBackResponse.SendResponse;
import database.DBFunctions;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TimerTask;

/**
 *
 * @author ERIC
 */
public class MobileMoneyResponse extends TimerTask {

    DBFunctions dbf = new DBFunctions();
    HashMap<String, String> response = new HashMap();
    String updatetablequery = "";
    ArrayList<HashMap<String, String>> responselist = new ArrayList<>();

    @Override
    public void run() {
        try {
             System.err.println("\n========-MNOB2C CALL RESPONSE-===========");
            responselist = dbf.getMnoB2CResponse();
            if (!responselist.isEmpty()) {
                System.out.println(responselist);
                for (HashMap<String, String> mno_record : responselist) {
                    updatetablequery = "UPDATE TBBULKUPLOADS_MNO SET RESPONSE_CODE ='" + mno_record.get("RESPONSECODE") + "', "
                            + " HOST_RESPONSE='" + mno_record.get("NARRATION") + "'"
                            + " where RECORD_ID='" + mno_record.get("RECORDID") + "' AND REFNO='" + mno_record.get("ESBREF") + "' ";

                    if (dbf.query(updatetablequery)) {
                        updatetablequery = "UPDATE TBMESSAGES SET FIELD24='UPLOADED' WHERE ID='" + mno_record.get("ID") + "' ";
                        if (dbf.query(updatetablequery)) {
                            response.put("RES_TYPE", "MNOB2C");
                            response.put("RECORDID", mno_record.get("RECORDID")); //FOR SINGLE TXN USE RECORD ID
                            response.put("TXNREFID", mno_record.get("ESBREF"));
                            response.put("DESCRIPTION", mno_record.get("NARRATION"));
                            response.put("STATUSCODE", mno_record.get("RESPONSECODE").equalsIgnoreCase("00") ? "1" : "2");
                            SendResponse sr = new SendResponse(response);
                            sr.httpsRequest();
                        }

                    }
                }

            } else {
                System.out.println(" NO UNSENT RESPONSE ");
            }

        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "MnoB2CResponse ->run()");
            el.log();
        }
    }

}
