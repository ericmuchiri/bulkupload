package database;

import LogEngine.ESBLog;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.*;
import javax.naming.*;
import utils.AESAlgorythim;

public class DBconn {

    public Connection conn = null;
    public Statement stmt = null;
    public ResultSet rs = null;
    public Context ctx = null;

    private String host, port, user, password, database, url;
    String driverName = "oracle.jdbc.driver.OracleDriver";

    public DBconn() {
        try {
            password = new AESAlgorythim().decrypt(Config.DB_PASSWORD);//  
            host = Config.DB_HOST;
            port = Config.DB_PORT;
            database = Config.DB_SID;
            user = Config.DB_USER;
            Class.forName(driverName);
            url = "jdbc:oracle:thin:@" + host + ":" + port + "/" + database;
            this.conn = DriverManager.getConnection(url, user.trim(), password.trim());
            this.stmt = conn.createStatement();
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }

    public void close() {
        try {
            //Close JDBC objects as soon as possible
            if (stmt != null) {
                stmt.close();
                stmt = null;
            }
            if (conn != null) {
                conn.close();
                conn = null;
            }
            //Close context
            if (ctx != null) {
                ctx.close();
            }

        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }

}
