package database;

import LogEngine.ESBLog;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class DBFunctions {

    private DBconn DBconn;
    private CallableStatement callableStatement = null;
    private PreparedStatement preparedstatement = null;

    public DBFunctions() {

    }

    private void getDBconn() {
        this.DBconn = new DBconn();
    }

    /**
     * Gets esb refnumber from database;
     *
     * @return CorrelationID
     */
    public String getCorrelationID() {
        String CorrelationID = null;
        String SP_GET_ESB_NEXT_SEQ = "{call SP_GET_ESB_NEXT_SEQ(?)}";
        try {
            getDBconn();
            callableStatement = DBconn.conn.prepareCall(SP_GET_ESB_NEXT_SEQ);
            callableStatement.registerOutParameter("cv_1", java.sql.Types.VARCHAR);
            callableStatement.executeUpdate();
            CorrelationID = callableStatement.getString("cv_1");
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "getCorrelationID()");
            el.log();
        }
        DBconn.close();
        return CorrelationID;
    }

    /**
     * Esb batchnumber for the file uplaod.
     *
     * @return
     */
    public String getEsbBatchNo() {
        String esbbatchnumber = null;
        try {
            String query = "select lpad(SEQ_GET_ESBBATCHNO.nextval,6,'0') AS ESB_BATCHNUMBER from dual";
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(query);
            while (DBconn.rs.next()) {
                esbbatchnumber = DBconn.rs.getString("ESB_BATCHNUMBER");
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog("getEsbBatchNo() -->" + sw.toString());
            el.log();
        }
        DBconn.close();
        return esbbatchnumber;
    }

    /**
     * Execute sql command
     *
     * @param query
     * @return true or false
     */
    public boolean query(String query) {
        boolean update = false;
        try {
            getDBconn();
            DBconn.stmt.executeQuery(query);
            update = true;
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "query(String query)");
            el.log();
        }
        DBconn.close();
        return update;
    }

    /**
     * checks for unprocessed batch in staging table TBBULKUPLOADS
     *
     * @return count of records in table
     */
    public int checkBatchOnQueue() {
        int count = 0;
        try {
            String query = "select count(*) as count from  TBBULKUPLOADS_MASTER";
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(query);
            while (DBconn.rs.next()) {
                count = DBconn.rs.getInt("count");
            }
        } catch (SQLException e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "checkBatchOnQueue()");
            el.log();
        }
        DBconn.close();
        return count;
    }

    /**
     * Sorts the records in the batch file to MNOb2c,NMBfts, otherbankEFT
     *
     * @return success true or false
     */
    public boolean splitBulkUploads() {
        boolean split = false;
        getDBconn();
        String CALL_SP_SPLIT_BULK_RECORDS = "{call SP_SPLIT_BULK_RECORDS()}";
        try {
            callableStatement = DBconn.conn.prepareCall(CALL_SP_SPLIT_BULK_RECORDS);
            callableStatement.execute();
            split = true;
            callableStatement.close();
        } catch (SQLException e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "splitBulkUploads()");
            el.log();
        }
        DBconn.close();
        return split;
    }

    /**
     * Check if the new file batch has already been uploaeded
     *
     * @param IBBATCHNO
     * @return number of records in the batchno if exists
     */
    public int checkArchivedBatch(String IBBATCHNO) {
        int ARCHIVEDBATCHRECORDS = 0;
        try {
            String query = "select COUNT(*) AS ARCHIVEDBATCHRECORDS from TBBULKUPLOADS_MASTER_archive where IB_BATCHNO = '" + IBBATCHNO + "'";
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(query);
            while (DBconn.rs.next()) {
                ARCHIVEDBATCHRECORDS = DBconn.rs.getInt("ARCHIVEDBATCHRECORDS");
            }
        } catch (SQLException e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "checkArchivedBatch(String IBBATCHNO)");
            el.log();
        }
        DBconn.close();
        return ARCHIVEDBATCHRECORDS;
    }

    /**
     * Inserts the extracted records to database
     *
     * @param bulkrecords - list of records found in the file
     * @return batchsuccess - true or false
     */
    public boolean SaveBulkRecords(ArrayList bulkrecords) {
        boolean batchsuccess = false;
        try {
            ESBLog ss = new ESBLog(Thread.currentThread().getName(),
                    sdf.format(new Date()) + " : Start Inserting " + bulkrecords.size() + " Records to db");
            ss.logConsole();

            getDBconn();
            String bulk_insert = "INSERT INTO TBBULKUPLOADS_MASTER ("
                    + "CURRENCY ,AMOUNT ,CR_ACCOUNT,  SORTCODE,ACCOUNTNAME,NARRATION,"
                    + "DR_ACCOUNT,TXNDATE,CLIENTNAME,IB_BATCHNO ,ESB_BATCHNO, FILENAME,DESTINATION_TYPE,RECORD_ID,SOURCE_ID"
                    + ") VALUES ( ?, ?, ?,?, ?, ?, ?, ?,?,?,?,?,?,?,?)";
            DBconn.conn.setAutoCommit(false);
            preparedstatement = DBconn.conn.prepareStatement(bulk_insert);
            for (int i = 0; i < bulkrecords.size(); i++) {
                HashMap<String, String> onerecord = (HashMap<String, String>) bulkrecords.get(i);
                preparedstatement.setString(1, onerecord.get("CURRENCY"));
                preparedstatement.setString(2, onerecord.get("AMOUNT"));
                preparedstatement.setString(3, onerecord.get("CRACCOUNT"));
                preparedstatement.setString(4, onerecord.get("SORTCODE"));
                preparedstatement.setString(5, onerecord.get("ACCOUNTNAME"));
                preparedstatement.setString(6, onerecord.get("NARRATION"));
                preparedstatement.setString(7, onerecord.get("DRACCOUNT"));
                preparedstatement.setString(8, onerecord.get("BATCHDATE"));
                preparedstatement.setString(9, onerecord.get("CLIENTNAME"));
                preparedstatement.setString(10, onerecord.get("FILE_BATCHNO"));
                preparedstatement.setString(11, onerecord.get("ESBBATCHNO"));
                preparedstatement.setString(12, onerecord.get("FILENAME"));
                preparedstatement.setString(13, onerecord.get("DESTINATION"));
                preparedstatement.setString(14, onerecord.get("RECORD_ID"));
                //added 
                preparedstatement.setString(15, onerecord.get("SOURCE_ID"));

                preparedstatement.addBatch();
            }
            preparedstatement.executeBatch();
            DBconn.conn.commit();
            batchsuccess = true;
            preparedstatement.clearBatch();
            preparedstatement.close();

            ESBLog ssc = new ESBLog(Thread.currentThread().getName(),
                    sdf.format(new Date()) + " : Completed Inserting " + bulkrecords.size() + " Records to db");
            ssc.logConsole();
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el2 = new ESBLog(sw.toString() + "SaveBulkRecords(ArrayList bulkrecords)");
            el2.log();
        }
        DBconn.close();
        return batchsuccess;
    }

    /**
     * Get single MNOB2C and send to esb for processing
     *
     * @return HashMap
     */
    public HashMap getSingleMNOB2C() {
        HashMap<String, String> hm = new HashMap();
        try {
            String query = "select DRACCOUNT,ESB_BATCHNO,ID,AMOUNT,MOBILE_NO,ESB_BULK_REFNO,SERVICE_CODE,RECORD_ID ";
            query += " from TBBULKUPLOADS_MNO WHERE PICKED_TOMNO=0 AND SENT_TO_MNO=0 AND RESPONSE_CODE='00' ";
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(query);
            while (DBconn.rs.next()) {
                hm.put("ID", DBconn.rs.getString("ID"));
                hm.put("ESB_BATCHNO", DBconn.rs.getString("ESB_BATCHNO"));
                hm.put("AMOUNT", DBconn.rs.getString("AMOUNT"));
                hm.put("MOBILE_NO", DBconn.rs.getString("MOBILE_NO"));
                hm.put("ESB_BULK_REFNO", DBconn.rs.getString("ESB_BULK_REFNO"));
                hm.put("SERVICE_CODE", DBconn.rs.getString("SERVICE_CODE"));
                hm.put("RECORD_ID", DBconn.rs.getString("RECORD_ID"));
                hm.put("DRACCOUNT", DBconn.rs.getString("DRACCOUNT"));

            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "getSingleMNOB2C()");
            el.log();
        }
        DBconn.close();
        return hm;
    }

    public HashMap getSingleMNOB2C1() {
        HashMap<String, String> hm = new HashMap();
        try {
            String query = "select ESB_BATCHNO,ID,AMOUNT,DRACCOUNT,MOBILE_NO,IB_BATCHNO,SERVICE_CODE,RECORD_ID from TBBULKUPLOADS_MNO where sent = 0 and picked = 0 and rownum <= 1 order by id asc ";
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(query);
            while (DBconn.rs.next()) {
                hm.put("ID", DBconn.rs.getString("ID"));
                hm.put("ESB_BATCHNO", DBconn.rs.getString("ESB_BATCHNO"));
                hm.put("AMOUNT", DBconn.rs.getString("AMOUNT"));
                hm.put("DRACCOUNT", DBconn.rs.getString("DRACCOUNT"));
                hm.put("MOBILE_NO", DBconn.rs.getString("MOBILE_NO"));
                hm.put("IB_BATCHNO", DBconn.rs.getString("IB_BATCHNO"));
                hm.put("SERVICE_CODE", DBconn.rs.getString("SERVICE_CODE"));
                hm.put("RECORD_ID", DBconn.rs.getString("RECORD_ID"));

            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "getSingleMNOB2C()");
            el.log();
        }
        DBconn.close();
        return hm;
    }

    /**
     * Qurries tb messages for the MNORequest from this adapter.
     *
     * @return
     */
    public ArrayList getMnoB2CResponse() {
        ArrayList<HashMap<String, String>> ftlist = new ArrayList<>();
        try {
            String query = "select ID, field24 as FLAG, FIELD25 AS RECORDID, field38 AS IBBATCH, "
                    + "field37 AS ESBREF, field39 AS RESPONSECODE,  NARRATION FROM TBMESSAGES  "
                    + "WHERE FIELD26 = 'BULKUPLOAD'  AND FIELD24 = 'NOUPLOAD'";
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(query);
            while (DBconn.rs.next()) {
                HashMap<String, String> hm = new HashMap();
                hm.put("ID", DBconn.rs.getString("ID"));
                hm.put("FLAG", DBconn.rs.getString("FLAG"));
                hm.put("RECORDID", DBconn.rs.getString("RECORDID"));
                hm.put("IBBATCH", DBconn.rs.getString("IBBATCH"));
                hm.put("ESBREF", DBconn.rs.getString("ESBREF"));
                hm.put("RESPONSECODE", DBconn.rs.getString("RESPONSECODE"));
                hm.put("NARRATION", DBconn.rs.getString("NARRATION") == null ? " " : DBconn.rs.getString("NARRATION"));
                ftlist.add(hm);
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString() + "getFTTXNToUploadToFLEX()");
            el.log();
        }
        DBconn.close();
        return ftlist;
    }

    /**
     * moves other banks eft transfers to flex for processing as one batch
     *
     * @return
     */
    public HashMap callSpMoveEFTBulkToFlex() {
        HashMap<String, String> hm = new HashMap();
        String SP_MOVE_EFTBULK_TOFLEX = "{call SP_MOVE_EFTBULK_TOFLEX(?,?)}";
        try {
            getDBconn();
            callableStatement = DBconn.conn.prepareCall(SP_MOVE_EFTBULK_TOFLEX);
            callableStatement.registerOutParameter("cv_1", java.sql.Types.VARCHAR);
            callableStatement.registerOutParameter("ov_source_id", java.sql.Types.VARCHAR);
            callableStatement.executeUpdate();
            hm.put("FILEBATCHNO", callableStatement.getString("cv_1"));
            hm.put("SOURCEID", callableStatement.getString("ov_source_id"));
            
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog("callSpMoveEFTBulkToFlex()" + sw.toString());
            el.log();
        }
        DBconn.close();
        return hm;
    }

    public String getUnProcessdMnoBatchInFlex() {
        String esb_batchnumber = null;
        String getbatchnumber = "SELECT DISTINCT ESB_BATCHNO FROM TBBULKUPLOADS_MNO WHERE SENT_TO_FLEX=0 AND PICKED_TO_FLEX=0 AND ROWNUM<=1";
        try {
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(getbatchnumber);
            while (DBconn.rs.next()) {
                esb_batchnumber = DBconn.rs.getString("ESB_BATCHNO");
            }
        } catch (Exception e) {
            e.printStackTrace();
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog("getUnProcessdMnoBatchInFlex()" + sw.toString());
            el.log();
        }
        DBconn.close();
        return esb_batchnumber;
    }

    public String getMnoCollectionAccount(String networkname) {
        String MnoCollectionAccount = null;
        String getbatchnumber = "select BILLERCOLLECTIONACCOUNT from  TBBILLERS where BILLERID='" + networkname + "'";
        try {
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(getbatchnumber);
            while (DBconn.rs.next()) {
                MnoCollectionAccount = DBconn.rs.getString("BILLERCOLLECTIONACCOUNT");
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog("getMnoCollectionAccount()" + sw.toString());
            el.log();
        }
        DBconn.close();
        return MnoCollectionAccount;
    }

    public ArrayList getBulkMnoFt(String esb_batchnumber) {
        ArrayList<HashMap<String, String>> bulkmnos = new ArrayList<>();
        String query = "SELECT SUM(AMOUNT) as AMOUNT,  SERVICE_CODE,IB_BATCHNO, DRACCOUNT,ESB_BATCHNO FROM TBBULKUPLOADS_MNO   WHERE ESB_BATCHNO='" + esb_batchnumber + "'   group by IB_BATCHNO,DRACCOUNT,ESB_BATCHNO,SERVICE_CODE";
        try {
            getDBconn();
            DBconn.rs = DBconn.stmt.executeQuery(query);
            while (DBconn.rs.next()) {
                HashMap<String, String> hm = new HashMap();
                hm.put("IB_BATCHNO", DBconn.rs.getString("IB_BATCHNO"));
                hm.put("AMOUNT", DBconn.rs.getString("AMOUNT"));
                hm.put("NETWORK", DBconn.rs.getString("SERVICE_CODE"));
                hm.put("DRACCOUNT", DBconn.rs.getString("DRACCOUNT"));
                hm.put("ESB_BATCHNO", DBconn.rs.getString("ESB_BATCHNO"));
                bulkmnos.add(hm);
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog("getBulkMnoFt()" + sw.toString());
            el.log();
        }
        return bulkmnos;
    }

}
