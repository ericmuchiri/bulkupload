/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import esbbulkfileupload.ESBBulkUpload;

/**
 *
 * @author ERIC
 */
public class Config {

    /**
     * All passwords are encrypted is Ecnrypted using AES algorthim and
     * ekeleaintl2016KE as key bytes
     */
    public static String MACHINE1 = ESBBulkUpload.appSetting.get("MACHINE1");
    public static String MACHINE2 = ESBBulkUpload.appSetting.get("MACHINE2");
    public static String PROVIDER_URL = ESBBulkUpload.appSetting.get("PROVIDER_URL");
    public static String SHAREDDIRECTORY = ESBBulkUpload.appSetting.get("SHAREDDIRECTORY");
    public static String ARCHIVEDIRECTORY = ESBBulkUpload.appSetting.get("ARCHIVEDIRECTORY");
    public static String DECRYPTIONKEY = ESBBulkUpload.appSetting.get("DECRYPTIONKEY");

    public static String PASSPHRASE = ESBBulkUpload.appSetting.get("PASSPHRASE"); ////P@ss1234
    public static String IBCALLBACKURL = ESBBulkUpload.appSetting.get("IBCALLBACKURL");
    public static String ESBWSConnector = ESBBulkUpload.appSetting.get("ESBWSConnector");

    public static String DB_PASSWORD = ESBBulkUpload.appSetting.get("DB_PASSWORD");
    public static String DB_USER = ESBBulkUpload.appSetting.get("DB_USER");
    public static String DB_HOST = ESBBulkUpload.appSetting.get("DB_HOST");
    public static String DB_PORT = ESBBulkUpload.appSetting.get("DB_PORT");
    public static String DB_SID = ESBBulkUpload.appSetting.get("DB_SID");

}
