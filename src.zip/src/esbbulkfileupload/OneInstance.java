package esbbulkfileupload;


import LogEngine.ESBLog;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
 

public class OneInstance implements Runnable {

    private static final int PORT_NUM = 3931;
    @Override
    public void run() {

        try {
            ServerSocket serverSocket = new ServerSocket(PORT_NUM);
            ESBBulkUpload.CHECK_INSTANCE = true;
            try {
                while (true) {
                    Socket socket = serverSocket.accept();
                    try {
                        PrintWriter out
                                = new PrintWriter(socket.getOutputStream(), true);
                        out.println("ESBBulkUpload RUNNING ON PORT: " + PORT_NUM + " " + new Date().toString());
                        System.out.println("ESBBulkUpload RUNNING ON PORT: " + PORT_NUM + " " + new Date().toString());
                    } finally {
                        socket.close();
                    }
                }
            } finally {
                serverSocket.close();
            }

        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog xresp = new ESBLog( "Unable to create ESBBulkUpload App. ESBBulkUpload May be running on port: "+PORT_NUM+"\n"+sw.toString());
            xresp.log();
            System.exit(0);
        }
    }

}
