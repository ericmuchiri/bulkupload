package esbbulkfileupload;

import LogEngine.ESBLog;
import ESBFT_TOFLEX.ProcessBankTransfer;
import fileprocessor.ProcessFile;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import java.util.Timer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import mno.MnoBulkFtToEsb;

public class ESBBulkUpload {

    public static boolean CHECK_INSTANCE = false;
    public static ExecutorService executor;
    public static SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss.SSS");
    public static HashMap<String, String> appSetting = new HashMap<>();

    public static HashMap<String, String> configmap = new HashMap();

    public static void main(String[] args) {

        executor = Executors.newFixedThreadPool(15);
        System.out.println("\n+--------------------------+");
        System.out.println("|  ESB BULK FILE UPLOAD    |");
        System.out.println("+--------------------------+\n");
        System.out.println("Modules Timing");
        try {
            (new Thread(new OneInstance())).start();
            loadconfigs();

            Timer ProcessFile = new Timer("ProcessFile");
            //start after 1 sencond and after every run wait 10 minutes and run again
            ProcessFile.schedule(new ProcessFile(), 1000 * 1 * 1, 1000 * 1 * 30);

            Timer otherbanktoflex = new Timer("MoveOtherBankToFlex");
            otherbanktoflex.schedule(new ProcessBankTransfer(), 1000 * 30 * 1, 1000 * 60 * 1);
//

            ////MNO B2C BULK FT
            Timer mnobulkft = new Timer("MnoBulkFt");
            mnobulkft.schedule(new MnoBulkFtToEsb(), 1000 * 1 * 1, 1000 * 1 * 11);

//              Timer sendtomno = new Timer("sendToMno");
//            sendtomno.schedule(new sendToMno(), 1000 * 1 * 20, 1000 * 1 * 11);
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }

   

    public static void loadconfigs() {
        InputStream input = null;
        try {
            Properties prop = new Properties();
            input = new FileInputStream("config.properties");
            prop.load(input);
            Enumeration<?> e = prop.propertyNames();
            while (e.hasMoreElements()) {
                String key = (String) e.nextElement();
                String value = prop.getProperty(key);
                appSetting.put(key, value);
            }
            appSetting.put("LOADCONFIG", "SUCCESS");
        } catch (Exception e) {
            appSetting.put("LOADCONFIG", "FAILLED");
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
            System.exit(0);
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    ESBLog el = new ESBLog(sw.toString());
                    el.log();
                    System.exit(0);
                }
            }
        }
    }

}
