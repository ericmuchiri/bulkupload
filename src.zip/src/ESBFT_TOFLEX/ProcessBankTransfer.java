package ESBFT_TOFLEX;

import LogEngine.ESBLog;
import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.TimerTask;

/**
 * Run Sp_move_to_flex
 *
 * @author ERIC
 */
public class ProcessBankTransfer extends TimerTask {

    String TRANSFER_TYPE = null;
    String SOURCEID = null;

    @Override
    public void run() {
        try {
            System.out.println("\n========<BANK FT TO FLEX>============");
            System.out.println(sdf.format(new Date()) + " STARTED BULK BANK FT ");
            PushToFlex ptflex = new PushToFlex();
            ////start with nmb fts
            ptflex.pushNMB();
            ////
            ptflex.pushOtherbank();
            ///end the process
            System.out.println(" ========</EFT>============\n");
        } catch (Exception e) {
            e.printStackTrace();
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }

    }

    public void responseHandler() {

    }

}
