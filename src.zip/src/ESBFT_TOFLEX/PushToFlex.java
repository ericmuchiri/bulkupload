/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ESBFT_TOFLEX;

import LogEngine.ESBLog;
import callBackResponse.SendResponse;
import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author ERIC
 */
public class PushToFlex {

    DBFunctions dbf = new DBFunctions();
    String ibbatchnumber = null;
    String source_id = null;
    HashMap<String, String> details = null;
    HashMap<String, String> callbackres = new HashMap<>();

    public PushToFlex() {

    }

    public void pushNMB() {

    }

    public void pushOtherbank() {
        details = dbf.callSpMoveEFTBulkToFlex();
        if (!details.isEmpty()) {
            ESBLog strt = new ESBLog(Thread.currentThread().getName(),
                    sdf.format(new Date()) + "  EFT BULK TO FLEX EXECUTED. -> IBBATCHNO: " + details.get("FILEBATCHNO"));
            strt.logConsole();
            responseHandler();

        } else {
            ESBLog strt = new ESBLog(Thread.currentThread().getName(),
                    sdf.format(new Date()) + "  NO PENDING BATCH ON QUEUE ");
            strt.logConsole();
        }
    }

    public void responseHandler() {
        if (details.get("SOURCEID").equalsIgnoreCase("IBCLIENT")) {
            callbackres.put("RES_TYPE", "BATCH_STATUS");
            callbackres.put("IBBATCHNO", details.get("SOURCEID"));
            callbackres.put("DESCRIPTION", "Transfer to other bank uploaded successful");
            callbackres.put("STATUSCODE", "1");
            SendResponse cbk = new SendResponse(callbackres);
            cbk.httpsRequest();
        }
    }

}
