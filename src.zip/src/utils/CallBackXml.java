/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import LogEngine.ESBLog;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.UUID;

/**
 *
 * @author ERIC
 */
public class CallBackXml {

    /**
     *
     * @param xmlmap
     * @return CALL BACK XML TO IBCLIENT
     */
    public String genBatchXml(HashMap xmlmap) {
        String xml = null;
        try {
            UUID uniqueKey = UUID.randomUUID();
            /*
        *From the email, document later ->
        when sending IB BATCHNUMBER-- REMOVE THE WORD "IB"
             */
            String REFID = xmlmap.get("IBBATCHNO").toString();
              xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                    + "	<soapenv:Header />\n"
                    + "	<soapenv:Body>\n"
                    + "		<IFX xmlns=\"http://soa.jboss.org/NettellerWS\"><![CDATA[\n"
                    + "<IFX xmlns=\"urn:ifxforum-org:XSD:1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n"
                    + "	xsi:schemaLocation=\"urn:ifxforum-org:XSD:1 C:\\Users\\User\\Desktop\\credIFX\\byFanos\\ifx-framework\\schema\\netteller\\IFX170_NETteller.xsd\">\n"
                    + "	<SignonRq>\n"
                    + "		<SignonPswd>\n"
                    + "			<SignonRole>Customer</SignonRole>\n"
                    + "			<CustId>\n"
                    + "				<SPName>cy.com.netinfo.netteller</SPName>\n"
                    + "				<CustPermId>00020239</CustPermId>\n"
                    + "				<!--CIF  OPTIONAL-->\n"
                    + "				<CustLoginId>586754</CustLoginId>\n"
                    + "				<!--LOGIN NAME  OPTIONAL-->\n"
                    + "			</CustId>\n"
                    + "			<CustPswd>\n"
                    + "				<CryptType>C</CryptType>\n"
                    + "				<Pswd/>\n"
                    + "			</CustPswd>\n"
                    + "		</SignonPswd>\n"
                    + "		<ClientDt>2008-06-30T12:00:00.000000+04:00</ClientDt>\n"
                    + "		<CustLangPref>en_US</CustLangPref>\n"
                    + "		<ClientApp>\n"
                    + "			<Org>netinfo.eu</Org>\n"
                    + "			<Name>Netteller</Name>\n"
                    + "			<Version>4.0</Version>\n"
                    + "		</ClientApp>\n"
                    + "		<ProxyClient>\n"
                    + "			<Org>cy.com.netinfo.netteller</Org>\n"
                    + "			<Name>XferInqBatchRq</Name>\n"
                    + "			<Version>4.0</Version>\n"
                    + "		</ProxyClient>\n"
                    + "	</SignonRq>\n"
                    + "	<BankSvcRq>\n"
                    + "		<RqUID>" + uniqueKey + "</RqUID>\n"
                    + "		<!--UNIQUE ID-->\n"
                    + "		<XferInqRq>\n"
                    + "			<RqUID>" + uniqueKey + "</RqUID>\n"
                    + "			<!--UNIQUE ID-->\n"
                    + "			<MsgRqHdr>\n"
                    + "				<PointOfServiceData>\n"
                    + "					<Environment>I</Environment>\n"
                    + "					<PostingSessionId>10.200.10.175</PostingSessionId>\n"
                    + "				</PointOfServiceData>\n"
                    + "			</MsgRqHdr>\n"
                    + "			<CustId>\n"
                    + "				<SPName>cy.com.netinfo.netteller</SPName>\n"
                    + "				<CustPermId>00020239</CustPermId>\n"
                    + "				<!--CIF  OPTIONAL-->\n"
                    + "			</CustId>\n"
                    + "			<XferId>" + xmlmap.get("IBBATCHNO").toString().replace("IB", "") + "</XferId>\n"
                    + "                     <RecXferId>" + REFID + "</RecXferId>"
                    + "                     <SPRefId>" + xmlmap.get("DESCRIPTION") + "</SPRefId>"
                    + "                     <XferStatusCode>" + xmlmap.get("STATUSCODE") + "</XferStatusCode> "
                    + "		</XferInqRq>\n"
                    + "	</BankSvcRq>\n"
                    + "</IFX>\n"
                    + "]]></IFX>\n"
                    + "	</soapenv:Body>\n"
                    + "</soapenv:Envelope>";

            String soapbody = xml.replaceAll("(\\r|\\n|\\t|\\r\\n\\t)+", "");
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog("Callxml ->genBatchXml()" + sw.toString());
            el.log();
        }

        return xml;
    }

    public String genTxnXml(HashMap xmlmap) {
        String xml = null;
        try {
            UUID uniqueKey = UUID.randomUUID();
              xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                    + "	<soapenv:Header />\n"
                    + "	<soapenv:Body>\n"
                    + "		<IFX xmlns=\"http://soa.jboss.org/NettellerWS\"><![CDATA[\n"
                    + "  <IFX xmlns=\"urn:ifxforum-org:XSD:1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"urn:ifxforum-org:XSD:1 C:\\Users\\User\\Desktop\\IFXSCH~1\\IFX170C.xsd\">\n"
                    + "	<SignonRq>\n"
                    + "		<SignonPswd>\n"
                    + "			<SignonRole>Customer</SignonRole>\n"
                    + "			<CustId>\n"
                    + "				<SPName>cy.com.netinfo.netteller</SPName>\n"
                    + "				<CustPermId>00020239</CustPermId>\n"
                    + "				<!--CIF  OPTIONAL-->\n"
                    + "				<CustLoginId>586754</CustLoginId>\n"
                    + "				<!--LOGIN NAME  OPTIONAL-->\n"
                    + "			</CustId>\n"
                    + "			<CustPswd>\n"
                    + "				<CryptType>C</CryptType>\n"
                    + "				<Pswd/>\n"
                    + "			</CustPswd>\n"
                    + "		</SignonPswd>\n"
                    + "		<ClientDt>2008-06-30T12:00:00.000000+04:00</ClientDt>\n"
                    + "		<CustLangPref>en_US</CustLangPref>\n"
                    + "		<ClientApp>\n"
                    + "			<Org>netinfo.eu</Org>\n"
                    + "			<Name>Netteller</Name>\n"
                    + "			<Version>4.0</Version>\n"
                    + "		</ClientApp>\n"
                    + "		<ProxyClient>\n"
                    + "			<Org>cy.com.netinfo.netteller</Org>\n"
                    + "			<Name>XferInqRq</Name>\n"
                    + "			<Version>4.0</Version>\n"
                    + "		</ProxyClient>\n"
                    + "	</SignonRq>\n"
                    + "	<BankSvcRq>\n"
                    + "		<RqUID>" + uniqueKey + "</RqUID>\n"
                    + "		<!--UNIQUE ID-->\n"
                    + "		<XferInqRq>\n"
                    + "			<RqUID>" + uniqueKey + "</RqUID>\n"
                    + "			<!--UNIQUE ID-->\n"
                    + "			<MsgRqHdr>\n"
                    + "				<PointOfServiceData>\n"
                    + "					<Environment>I</Environment>\n"
                    + "					<PostingSessionId>10.200.10.175</PostingSessionId>\n"
                    + "				</PointOfServiceData>\n"
                    + "			</MsgRqHdr>\n"
                    + "			<CustId>\n"
                    + "				<SPName>cy.com.netinfo.netteller</SPName>\n"
                    + "				<CustPermId>00020239</CustPermId>\n"
                    + "				<!--CIF  OPTIONAL-->\n"
                    + "			</CustId>\n"
                    + "			<XferId>" + xmlmap.get("RECORDID").toString() + "</XferId>\n"
                    + "			<!--NETTELLER UTN-->\n"
                    + "			<RecXferId>" + xmlmap.get("TXNREFID").toString() + "</RecXferId>\n"
                    + "			<!--UTN FROM CORE -->\n"
                    + "			<SPRefId>" + xmlmap.get("DESCRIPTION").toString() + "</SPRefId>\n"
                    + "			<!--STATUS DESCRIPTION-->\n"
                    + "			<XferStatusCode>" + xmlmap.get("STATUSCODE").toString() + "</XferStatusCode>\n"
                    + "			<!--STATUS CODE-->\n"
                    + "		</XferInqRq>\n"
                    + "	</BankSvcRq>\n"
                    + "</IFX>"
                    + "]]></IFX>\n"
                    + "	</soapenv:Body>\n"
                    + "</soapenv:Envelope>";
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog("Callxml ->genStatus()" + sw.toString());
            el.log();
        }

        return xml;
    }
}
