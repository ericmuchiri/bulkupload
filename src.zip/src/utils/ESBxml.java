package utils;

import LogEngine.ESBLog;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ESBxml extends DefaultHandler {

    HashMap xmlmap = new HashMap<String, String>();
    String tmpValue = "";

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (qName.equalsIgnoreCase("field")) {
            xmlmap.put(attributes.getValue(0), attributes.getValue(1));
            //System.out.println(attributes.getValue(0) + " : " + attributes.getValue(1));
        }
        if (qName.equalsIgnoreCase("isomsg")) {
            xmlmap.put("direction", attributes.getValue(0));
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        tmpValue = new String(ch, start, length);
    }

    public HashMap parseESBXML(String xmlESB) {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            saxParser.parse(new InputSource(new StringReader(xmlESB)), this);
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
        return xmlmap;
    }

    public String generateXMLfromMap(HashMap<String, String> xmlmap, boolean request) {
        ///added authheader since its a request
        String xmlhead = "<?xml version=\"1.0\" encoding=\"utf-8\"?><message><authHeader sourceid='ESB' password='ESB' /><isomsg direction=\"" + (request ? "request" : "response") + "\">";
        String xmltail = "</isomsg></message>";
        for (Map.Entry<String, String> entry : xmlmap.entrySet()) {
            String id = entry.getKey();
            String value = entry.getValue();
            xmlhead += "<field id='" + id + "' value='" + value + "' />";
        }
        xmlhead = xmlhead + xmltail;
        return xmlhead;
    }

}
