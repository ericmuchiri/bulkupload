package fileprocessor;

import LogEngine.ESBLog;
import callBackResponse.SendResponse;
import database.Config;

import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class CSVFileReader {

    DBFunctions dbf = new DBFunctions();
    String ESBBATCHNO = null;
    /**
     * Debit information> dracc,drname,drsorce etc
     */
    HashMap<String, String> DR_INFO = new HashMap();
    String DECRYPTEDFILEPATH = null;
    String sCurrentLine = null;
    BufferedReader br = null;
    String DecryptedFile = null;
    String encrypted_file_name = null;
    HashMap<String, String> callbackres = new HashMap<>();
    String sArchiveDirectory = Config.ARCHIVEDIRECTORY;
    String SOURCE_ID = null;

    /**
     * Constrct decrypted file.
     *
     * @param filedecrepted
     */
    public CSVFileReader(String filedecrepted) {
        this.DecryptedFile = filedecrepted;
        //for the record
        this.encrypted_file_name = filedecrepted.replace(".csv", ".pgp");
        this.SOURCE_ID = filedecrepted.split("-")[0];
    }

    /**
     * Control method to call extract method, and save method
     */
    public void CSVReader() {
        try {
            ///get file records
            ArrayList<HashMap<String, String>> extracted_records = extractCsvDataToHashmap();
            FileValidation respond = new FileValidation(encrypted_file_name);

            if (!extracted_records.isEmpty()) {
                if (dbf.SaveBulkRecords(extracted_records)) {
                    ESBLog ss = new ESBLog(Thread.currentThread().getName(),
                            sdf.format(new Date()) + " :  RECORDS UPLOAD TO DATABASE SUCCESS. FILE-> " + DecryptedFile);
                    ss.logConsole();
                    //split records to various
                    dbf.splitBulkUploads();

                    FilePicker.ArchiveFile(sArchiveDirectory + "/WORKING/", sArchiveDirectory + "/SUCCESS/", DecryptedFile);
                    ///send response as success
                    respond.dataUploaded("1");

                } else {

                    FilePicker.ArchiveFile(sArchiveDirectory + "/WORKING/", sArchiveDirectory + "/FAILED/DATABASEUPLOAD/", DecryptedFile);
                    ESBLog ss = new ESBLog(Thread.currentThread().getName(),
                            sdf.format(new Date()) + " :  DATABASE UPLOAD FAILED. FILE-> " + DecryptedFile);
                    ss.logConsole();
                    ///send response as failed
                    respond.dataUploaded("2");
                }
            }

        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        } finally {
            //delete the file after the job is finished
            FilePicker.DeleteFile(DECRYPTEDFILEPATH);
        }

    }

    /**
     * Reads the csv, check if batchnumber is the same as file name Sends the
     * call back Message if validation failed for batchnumber
     *
     * @return FILERECORDS
     */
    public ArrayList extractCsvDataToHashmap() {
        ArrayList<HashMap<String, String>> FILERECORDS = new ArrayList();
        String SRC_BATCHNUMBER_file = DecryptedFile.split("-")[1].replace(".csv", "");

        FileValidation validate = new FileValidation(encrypted_file_name);

        try {
            String batchno = dbf.getEsbBatchNo();
            if (batchno != null) {
                ESBBATCHNO = "BN" + batchno;

                ESBLog strt = new ESBLog(Thread.currentThread().getName(),
                        sdf.format(new Date()) + " : START READING FILE " + DecryptedFile + " "
                        + "ESB BATCHNO : " + ESBBATCHNO);
                strt.logConsole();

                DECRYPTEDFILEPATH = sArchiveDirectory + "WORKING/" + DecryptedFile;
                br = new BufferedReader(new java.io.FileReader(DECRYPTEDFILEPATH));
                Integer linenumber = 0;
                ///remove the source id and file extension like obove methods

                while ((sCurrentLine = br.readLine()) != null && !"".equals(sCurrentLine)) {
                    linenumber++;
                    sCurrentLine = sCurrentLine.replace("\"", ""); //remove double quotes
                    sCurrentLine = sCurrentLine.replace("\'", ""); //remove single quotes
                    String[] linedata = sCurrentLine.split(",");

                    if (linenumber == 1) {
                        String SRCBATCHNO_FROMDATA = linedata[1].trim();
                        DR_INFO.put("BATCHDATE", linedata[0].trim());
                        DR_INFO.put("FILE_BATCHNO", SRCBATCHNO_FROMDATA);
                        DR_INFO.put("DRACCOUNT", linedata[2].trim());
                        DR_INFO.put("CLIENTNAME", linedata[3].trim());
                        DR_INFO.put("ESBBATCHNO", ESBBATCHNO.trim());
                        DR_INFO.put("FILENAME", DecryptedFile);
                        ///add source id 
                        DR_INFO.put("SOURCE_ID", SOURCE_ID);

                        if (!validate.isFileNameMatchBatchNo(SRC_BATCHNUMBER_file)) {
                            FILERECORDS.clear();
                            break;
                        }

                    } else {
                        HashMap<String, String> onerecord = new HashMap(DR_INFO);
                        onerecord.put("RECORD_ID", linedata[0].trim());
                        onerecord.put("DESTINATION", linedata[1].trim());
                        onerecord.put("SORTCODE", linedata[2].trim());
                        onerecord.put("CRACCOUNT", linedata[3].trim());
                        onerecord.put("ACCOUNTNAME", linedata[4].trim());
                        onerecord.put("AMOUNT", linedata[5].trim());
                        onerecord.put("CURRENCY", linedata[6].trim());
                        onerecord.put("NARRATION", linedata[7].trim());
                        FILERECORDS.add(onerecord);
                    }
                }

                ESBLog lg = new ESBLog(Thread.currentThread().getName(),
                        sdf.format(new Date()) + " :  Reading  " + DecryptedFile + " Complete "
                        + " with " + linenumber + " records");
                lg.logConsole();
            } else {
                FilePicker.ArchiveFile(sArchiveDirectory + "/WORKING/", sArchiveDirectory + "/FAILED/DATABASEGETBATCHNO/", DecryptedFile);
                ESBLog strt = new ESBLog(Thread.currentThread().getName(),
                        sdf.format(new Date()) + " :  Failed to get esbbatchnumber . ");
                strt.logConsole();
            }
        } catch (Exception e) {
            validate.dataExtractionFailed();

            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        } finally {
            if (br != null) {
                try {
                    br.close();

                } catch (Exception e) {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    ESBLog el = new ESBLog(sw.toString());
                    el.log();
                }
            }
        }
        return FILERECORDS;
    }
}
