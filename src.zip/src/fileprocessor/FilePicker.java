package fileprocessor;

import LogEngine.ESBLog;
import database.Config;

import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.File;
import java.io.FileFilter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.FileFileFilter;

/**
 * 1. Check if unprocessed exists 2. Pick file 3. Get Source_file 4. Decrypt
 * File 5. Invoke CsvReader to extract
 *
 * @author ERIC
 */
public class FilePicker {

    String ENCRYPTED_FILE = "";
    String DECRYPTED_FILE = "";
    String DECRYPTED_FILE_PATH = "";
    String EXT = "";
    String sSharedDirectory = Config.SHAREDDIRECTORY;
    String sArchiveDirectory = Config.ARCHIVEDIRECTORY;
    /**
     * The client that is droping the file
     */
    String SOURCE_ID = null;

    String[] DEFINED_SOURCES = {"PPF", "IBCLIENT"};

    HashMap<String, String> callbackres = new HashMap<>();

    /**
     * Picks one File Do initial validation Sends Callback message if failed
     * Call Decryption Method
     */
    public void pickFile() {
        try {
            File directory = new File(sSharedDirectory); ///FIFO
            File[] listoffiles = directory.listFiles((FileFilter) FileFileFilter.FILE);

            if (listoffiles.length > 0) {
                //pick one file from the directory - fifo
                Arrays.sort(listoffiles, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
                File rawfile = listoffiles[0];
                if (rawfile.isFile()) {
                    ///file is in sample PPF-1234567.PGP
                    ENCRYPTED_FILE = rawfile.getName();
                    SOURCE_ID = ENCRYPTED_FILE.split("-")[0];
                    ESBLog inqa = new ESBLog(Thread.currentThread().getName(),
                            sdf.format(new Date()) + " :  FILE PICKED: " + ENCRYPTED_FILE);
                    inqa.logConsole();
                    if (Arrays.asList(DEFINED_SOURCES).contains(SOURCE_ID)) {
                       
                        FileValidation validate = new FileValidation(ENCRYPTED_FILE);
                        EXT = FilenameUtils.getExtension(sSharedDirectory + ENCRYPTED_FILE);
                        if (validate.isPGPFile(EXT)) {
                            //check if exist in db
                            if (!validate.checkIfExistInArchive()) {
                                decryptFileUpload();
                            }
                        }
                    } else {
                        ArchiveFile(sSharedDirectory, sArchiveDirectory + "/FAILED/UNDEFINED_SOURCEID/", ENCRYPTED_FILE);
                        ESBLog inq = new ESBLog(Thread.currentThread().getName(),
                                sdf.format(new Date()) + " : Source of file is not defined");
                        inq.logConsole();
                    }
                }
            } else {
                ESBLog inq = new ESBLog(Thread.currentThread().getName(),
                        sdf.format(new Date()) + " :  NO FILE IN DIRECTORY");
                inq.logConsole();
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }

    /**
     * Decrypt File Initialize the CsvReader Sends callback Message when failed
     */
    public void decryptFileUpload() {

        try {
            DECRYPTED_FILE = FilenameUtils.removeExtension(ENCRYPTED_FILE) + ".csv"; //ENCRYPTED_FILE
            DECRYPTED_FILE_PATH = sArchiveDirectory + "WORKING/" + DECRYPTED_FILE;
            //validate encryption
            FileValidation validate = new FileValidation(ENCRYPTED_FILE);
            if (validate.isFileDecrypted(DECRYPTED_FILE_PATH)) {
                ESBLog drc = new ESBLog(Thread.currentThread().getName(),
                        "\n" + sdf.format(new Date()) + " :  File Decrypted Successfully ");
                drc.logConsole();

                CSVFileReader fr = new CSVFileReader(DECRYPTED_FILE);
                fr.CSVReader();
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        } finally {
            DeleteFile(sSharedDirectory + "/" + ENCRYPTED_FILE);
        }

    }

    /**
     *
     * @param source - source directory
     * @param destination - destination directory
     * @param filetomove - file to move
     */
    public static void ArchiveFile(String source, String destination, String filetomove) {
        try {
            SimpleDateFormat todaydateformat = new SimpleDateFormat("dd-MMM-yyyy");
            String date_dir_name = todaydateformat.format(new Date());
            String todaysfolder = destination + date_dir_name + "/";
            File new_dir = new File(todaysfolder);
            FileUtils.forceMkdir(new_dir);
            File sourcePath = new File(source + filetomove);
            File destinationPath = new File(todaysfolder + filetomove);
            int counter = 1;
            String baseName = FilenameUtils.getBaseName(destinationPath.getName());
            String extension = FilenameUtils.getExtension(destinationPath.getName());
            //add repitation index if file exist
            while (destinationPath.exists()) {
                destinationPath = new File(destinationPath.getParent(), baseName + "_(" + (counter++) + ")." + extension);
            }
            FileUtils.moveFile(sourcePath, destinationPath);
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }

    /**
     *
     * @param filepath
     */
    public static void DeleteFile(String filepath) {
        try {
            File deletefile = new File(filepath);
            FileUtils.deleteQuietly(deletefile);
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }

}
