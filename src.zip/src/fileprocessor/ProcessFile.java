package fileprocessor;

import LogEngine.ESBLog;
import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.TimerTask;
import java.util.Date;

public class ProcessFile extends TimerTask {

    String logMessage = "";
    DBFunctions dbf = new DBFunctions();

    @Override
    public void run() {
        try {
            System.err.println("\n========<FILE>============");
            ESBLog lg = new ESBLog(Thread.currentThread().getName(), sdf.format(new Date()) + " FILE PROCESSING STARTED...");
            lg.logConsole();
            int countofrecordsintable = dbf.checkBatchOnQueue();
            if (countofrecordsintable <= 0) {
                //no data in bulk table you can read file and upload
                FilePicker fp = new FilePicker();
                fp.pickFile();
            } else {
                //there is data in main bulk table call sp to slit it
                dbf.splitBulkUploads();
                ESBLog inq = new ESBLog(Thread.currentThread().getName(),
                        sdf.format(new Date()) + " : " + countofrecordsintable + " RECORDS FOUND IN TBBULKUPLOADS. SPLITING TBBULKUPLOADS...");
                inq.logConsole();
            }
            System.err.println("========</FILE>============\n");
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }

}
