/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileprocessor;

import LogEngine.ESBLog;
import callBackResponse.SendResponse;
import database.Config;
import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import static fileprocessor.FilePicker.ArchiveFile;
import static fileprocessor.FilePicker.DeleteFile;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.HashMap;
import pgp.PGPFileProcessor;
import utils.AESAlgorythim;

/**
 *
 * @author ERIC
 */
public class FileValidation {

    String ENCRYPTED_FILE = null;
    String SOURCE_ID = null;
    String FILEBATCHNO = null;
    DBFunctions dbf = new DBFunctions();
    String sSharedDirectory = Config.SHAREDDIRECTORY;
    String sArchiveDirectory = Config.ARCHIVEDIRECTORY;
    /**
     * hashmap with callback response to ib client
     */
    HashMap<String, String> callbackres = new HashMap<>();

    public FileValidation(String EncryptedFile) {
        this.ENCRYPTED_FILE = EncryptedFile;
        this.SOURCE_ID = EncryptedFile.split("-")[0];
        this.FILEBATCHNO = EncryptedFile.split("-")[1].replace(".pgp", "");
    }

    public boolean isPGPFile(String Ext) {
        boolean isPGPFile = false;
        try {
            if (Ext.equalsIgnoreCase("PGP")) {
                isPGPFile = true;
                System.out.println("PGP file format: Passed");
            } else {
                System.out.println("PGP file format: Failed");
                ArchiveFile(sSharedDirectory, sArchiveDirectory + "FAILED/INVALID_FILE_FORMAT/", ENCRYPTED_FILE);
                if (SOURCE_ID.equalsIgnoreCase("IBCLIENT")) {
                    callbackres.put("RES_TYPE", "BATCH_STATUS");
                    callbackres.put("IBBATCHNO", ENCRYPTED_FILE.replace(".pgp", ""));
                    callbackres.put("DESCRIPTION", "Invalid File Format");
                    callbackres.put("STATUSCODE", "2");
                    SendResponse cbk = new SendResponse(callbackres);
                    cbk.httpsRequest();

                }
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
        return isPGPFile;
    }

    public boolean checkIfExistInArchive() {
        boolean exist_in_archive = true;
        int countrecordsforbatchinarchive = dbf.checkArchivedBatch(FILEBATCHNO);
        if (countrecordsforbatchinarchive <= 0) {
            exist_in_archive = false;
            System.out.println("File Batchnumber Exist : >False ");
        } else {
            //archive file
            ArchiveFile(sSharedDirectory, sArchiveDirectory + "/FAILED/REPEATED_FILE/", ENCRYPTED_FILE);
            //send notifications
            System.out.println("File Batchnumber Exist : !Yes ");
            if (SOURCE_ID.equalsIgnoreCase("IBCLIENT")) {
                callbackres.put("RES_TYPE", "BATCH_STATUS");
                callbackres.put("IBBATCHNO", FILEBATCHNO);
                callbackres.put("DESCRIPTION", "Duplicate of IB Batch number");
                callbackres.put("STATUSCODE", "2");
                SendResponse cbk = new SendResponse(callbackres);
                cbk.httpsRequest();
            }
            ESBLog lgg = new ESBLog(Thread.currentThread().getName(),
                    sdf.format(new Date()) + " :  DATA FOR FILE " + ENCRYPTED_FILE + " "
                    + "FOUND IN ARCHIVE TABLE. PROCESSING STOPED. NUMBER OF RECORDS: " + countrecordsforbatchinarchive);
            lgg.logConsole();
        }
        return exist_in_archive;
    }

    public boolean isFileDecrypted(String DECRYPTED_FILE_PATH) {
        boolean isFileDecrypted = false;
        try {
            ESBLog strt = new ESBLog(Thread.currentThread().getName(),
                    sdf.format(new Date()) + " : Start Decrypting File ");
            strt.logConsole();

            PGPFileProcessor pgp = new PGPFileProcessor();
            pgp.setInputFile(sSharedDirectory + ENCRYPTED_FILE);
            pgp.setKeyFile(Config.DECRYPTIONKEY);
            //pass a decrypted key
            pgp.setPassphrase(new AESAlgorythim().decrypt(Config.PASSPHRASE));
            pgp.setOutputFile(DECRYPTED_FILE_PATH);
            pgp.decrypt();
            isFileDecrypted = true;
        } catch (Exception e) {
            ArchiveFile(sSharedDirectory, sArchiveDirectory + "FAILED/ENCRYPTION_ERROR/", ENCRYPTED_FILE);
            DeleteFile(DECRYPTED_FILE_PATH);
            //log
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
            //response
            if (SOURCE_ID.equalsIgnoreCase("IBCLIENT")) {
                callbackres.put("RES_TYPE", "BATCH_STATUS");
                callbackres.put("IBBATCHNO", FILEBATCHNO);
                callbackres.put("DESCRIPTION", "Decryption failed Error:" + e.getMessage());
                callbackres.put("STATUSCODE", "2");
                SendResponse cbk = new SendResponse(callbackres);
                cbk.httpsRequest();
            }

        }
        return isFileDecrypted;
    }

    /**
     * Checks if the batchnumber from file name match batchnumber from file
     *
     * @param batchnumber_in_file
     * @return
     * @throws Exception
     */
    public boolean isFileNameMatchBatchNo(String batchnumber_in_file) throws Exception {
        boolean issame = false;
        try {
            if (FILEBATCHNO.equalsIgnoreCase(batchnumber_in_file)) {
                System.out.println("Batch number match  filename:  pass");
                issame = true;
            } else {
                System.out.println("Batch number dont match filename: fail");
                if (SOURCE_ID.equalsIgnoreCase("IBCLIENT")) {
                    callbackres.put("RES_TYPE", "BATCH_STATUS");
                    callbackres.put("IBBATCHNO", FILEBATCHNO);
                    callbackres.put("DESCRIPTION", "File name and batch number in file don't match");
                    callbackres.put("STATUSCODE", "2");
                    SendResponse cbk = new SendResponse(callbackres);
                    cbk.httpsRequest();
                }
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }

        return issame;
    }

    /**
     * Send response to the source id when this happens
     *
     */
    public void dataExtractionFailed() {
        try {
            if (SOURCE_ID.equalsIgnoreCase("IBCLIENT")) {
                callbackres.put("RES_TYPE", "BATCH_STATUS");
                callbackres.put("IBBATCHNO", FILEBATCHNO);
                callbackres.put("DESCRIPTION", "Could not read csv file.");
                callbackres.put("STATUSCODE", "2");
                SendResponse cbk = new SendResponse(callbackres);
                cbk.httpsRequest();
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }

    }

    public void dataUploaded(String status) {
        try {
            if (SOURCE_ID.equalsIgnoreCase("IBCLIENT")) {
                callbackres.put("RES_TYPE", "BATCH_STATUS");
                callbackres.put("IBBATCHNO", FILEBATCHNO);
                callbackres.put("DESCRIPTION", status.equalsIgnoreCase("1") ? "Uploaded Successfuly" : "Failed uploading data");
                callbackres.put("STATUSCODE", status);
                SendResponse cbk = new SendResponse(callbackres);
                cbk.httpsRequest();
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
    }
}
