package callBackResponse;


import utils.CallBackXml;
import LogEngine.ESBLog;
import database.Config;

import database.DBFunctions;
import static esbbulkfileupload.ESBBulkUpload.sdf;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.util.Date;
import java.util.HashMap;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPMessage;
import org.w3c.dom.NodeList;
/**
 * 
 * @author ERIC
 */
public final class SendResponse {

    String requestXml = null;
    HashMap<String, String> callbackmap = new HashMap<>();
    HashMap<String, String> response_details = null;
    DBFunctions dbf = new DBFunctions();
    CallBackXml cxml = new CallBackXml();

    /**
     * Recieves batch and transaction details stastuses
     *
     * @param details
     */
    public SendResponse(HashMap details) {
        this.callbackmap = details;
    }

    /**
     * Send Xml to IB CLIENT
     */
    public void httpsRequest() {
        String response = "";
        try {
            ESBLog reqmap = new ESBLog(Thread.currentThread().getName(), "\n" + sdf.format(new Date()) + " **Call Request" + callbackmap.toString());
            reqmap.logConsole();

            if (callbackmap.get("RES_TYPE").equalsIgnoreCase("BATCH_STATUS")) {
                requestXml = cxml.genBatchXml(callbackmap);
            } else {
                requestXml = cxml.genTxnXml(callbackmap);
            }
            ESBLog req = new ESBLog("callbackXml", requestXml);
            req.log();
            ///request
            requestXml.replaceAll("\n", "");
            // Create a context that doesn't check certificates.
            HttpsURLConnection con = getConnection(Config.IBCALLBACKURL);
            con.setDoOutput(true);
            con.setRequestProperty("Content-type", "text/xml; charset=utf-8");
            con.setConnectTimeout(15000);
            con.setReadTimeout(45000);
            OutputStream reqStream = con.getOutputStream();
            reqStream.write(requestXml.getBytes());

            //response
            StringBuffer stringBuffer = new StringBuffer();
            String inputLine;
            BufferedReader bufferedReader = null;
            InputStream resStream = con.getInputStream();
            InputStreamReader streamReader = new InputStreamReader(resStream);
            bufferedReader = new BufferedReader(streamReader);
            while ((inputLine = bufferedReader.readLine()) != null) {
                stringBuffer.append(inputLine);
            }
            response = stringBuffer.toString();
            int responseCode = con.getResponseCode();
            if (responseCode == 200) {
                SoapMessageParser smp = new SoapMessageParser(response);
                response_details = smp.parsSoapMessage();

                ESBLog ress = new ESBLog(Thread.currentThread().getName(), "\n" + sdf.format(new Date()) + "**Call Response" + response_details.toString());
                ress.logConsole();

                if (callbackmap.get("RES_TYPE").equalsIgnoreCase("MNOB2C")) {
                    String sqlupdate = " UPDATE TBBULKUPLOADS_MNO SET CALLBACKSENT=1 WHERE RECORD_ID='" + callbackmap.get("RECORD_ID") + "'";
                    dbf.query(sqlupdate);
                }
                if (callbackmap.get("RES_TYPE").equalsIgnoreCase("OTHER_BANK")) {
                    //update tbotherbank arhcive has sent
                    String sqlupdate = " UPDATE TBBULKUPLOADS_OTHBNK_ARCHIVE SET RESPONSE_SENT=1 WHERE IBBATCHNUMBER='" + callbackmap.get("IBBATCHNO") + "'";
                    dbf.query(sqlupdate);
                }
            }
            con.disconnect();
        } catch (Exception ex) {

            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog("sendResponse ->httpsRequest()" + sw.toString());
            el.log();
        }
        ESBLog esbLog2 = new ESBLog("Responsefromib", response);
        esbLog2.log();
    }

    private TrustManager[] get_trust_mgr() {
        TrustManager[] certs = new TrustManager[]{
            new javax.net.ssl.X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String t) {
                }

                public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String t) {
                }
            }
        };
        return certs;
    }

    private HttpsURLConnection getConnection(String https_url) {
        HttpsURLConnection con = null;
        try {
            SSLContext ssl_ctx = SSLContext.getInstance("TLS");
            TrustManager[] trust_mgr = get_trust_mgr();
            ssl_ctx.init(null, // key manager
                    trust_mgr, // trust manager
                    new SecureRandom()); // random number generator
            URL url;
            HttpsURLConnection.setDefaultSSLSocketFactory(ssl_ctx.getSocketFactory());
            url = new java.net.URL(null, https_url, new sun.net.www.protocol.https.Handler());
            con = (HttpsURLConnection) url.openConnection();
            con.setHostnameVerifier(new HostnameVerifier() {
                public boolean verify(String host, SSLSession sess) {
                    return true;
                }
            });
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            ESBLog el = new ESBLog(sw.toString());
            el.log();
        }
        return con;
    }

    public void parseSoapEnvelope(String soapmsg) {
        try {
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage(
                    new MimeHeaders(),
                    new ByteArrayInputStream(soapmsg.getBytes(Charset
                            .forName("UTF-8"))));
            SOAPBody body = message.getSOAPBody();
            NodeList returnList = body.getElementsByTagName("IFXResponse");

        } catch (Exception e) {

        }

    }

  

}
