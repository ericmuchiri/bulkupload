package callBackResponse;

import LogEngine.ESBLog;
import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.util.HashMap;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPMessage;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

class SoapMessageParser {

    HashMap<String, String> rs_status = new HashMap();
    String messagebody;

    public SoapMessageParser(String soapmessage) {
        this.messagebody = getSoapBody(soapmessage);
    }

    public HashMap parsSoapMessage() {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(messagebody)));

            // Get the document's root XML node
            NodeList root = doc.getChildNodes();

            // Navigate down the hierarchy to get to the CEO node
            Node comp = getNode("IFX", root);
            Node exec = getNode("BaseSvcRs", comp.getChildNodes());
            Node status = getNode("Status", exec.getChildNodes());
            String execType = getNodeAttr("type", status);

            // Load the executive's data from the XML to hashmap
            NodeList nodes = status.getChildNodes();
            rs_status.put("STATUSCODE", getNodeValue("StatusCode", nodes));
            rs_status.put("SERVERSTATUSCODE", getNodeValue("ServerStatusCode", nodes));
            rs_status.put("DESCRIPTION", getNodeValue("StatusDesc", nodes));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return rs_status;
    }

    private String getSoapBody(String soap_message) {
        String soapbody = "";
        try {
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage(
                    new MimeHeaders(),
                    new ByteArrayInputStream(soap_message.getBytes(Charset
                            .forName("UTF-8"))));
            QName bodyName = new QName("http://soa.jboss.org/NettellerWS", "IFXResponse", "d");
            SOAPBody sb = message.getSOAPBody();
            java.util.Iterator iterator = sb.getChildElements(bodyName);
            while (iterator.hasNext()) {
                SOAPBodyElement bodyElement = (SOAPBodyElement) iterator.next();
                soapbody = bodyElement.getValue();
            }
        } catch (Exception e) {

        }
//        ESBLog esbLog2 = new ESBLog("i", soapbody);
//        esbLog2.log();
        return soapbody;
    }

    private static Node getNode(String tagName, NodeList nodes) {
        for (int x = 0; x < nodes.getLength(); x++) {
            Node node = nodes.item(x);
            if (node.getNodeName().equalsIgnoreCase(tagName)) {
                return node;
            }
        }

        return null;
    }

    private String getNodeValue(Node node) {
        NodeList childNodes = node.getChildNodes();
        for (int x = 0; x < childNodes.getLength(); x++) {
            Node data = childNodes.item(x);
            if (data.getNodeType() == Node.TEXT_NODE) {
                return data.getNodeValue();
            }
        }
        return "";
    }

    private String getNodeValue(String tagName, NodeList nodes) {
        for (int x = 0; x < nodes.getLength(); x++) {
            Node node = nodes.item(x);
            if (node.getNodeName().equalsIgnoreCase(tagName)) {
                NodeList childNodes = node.getChildNodes();
                for (int y = 0; y < childNodes.getLength(); y++) {
                    Node data = childNodes.item(y);
                    if (data.getNodeType() == Node.TEXT_NODE) {
                        return data.getNodeValue();
                    }
                }
            }
        }
        return "";
    }

    private String getNodeAttr(String attrName, Node node) {
        NamedNodeMap attrs = node.getAttributes();
        for (int y = 0; y < attrs.getLength(); y++) {
            Node attr = attrs.item(y);
            if (attr.getNodeName().equalsIgnoreCase(attrName)) {
                return attr.getNodeValue();
            }
        }
        return "";
    }

    private String getNodeAttr(String tagName, String attrName, NodeList nodes) {
        for (int x = 0; x < nodes.getLength(); x++) {
            Node node = nodes.item(x);
            if (node.getNodeName().equalsIgnoreCase(tagName)) {
                NodeList childNodes = node.getChildNodes();
                for (int y = 0; y < childNodes.getLength(); y++) {
                    Node data = childNodes.item(y);
                    if (data.getNodeType() == Node.ATTRIBUTE_NODE) {
                        if (data.getNodeName().equalsIgnoreCase(attrName)) {
                            return data.getNodeValue();
                        }
                    }
                }
            }
        }

        return "";
    }
}
